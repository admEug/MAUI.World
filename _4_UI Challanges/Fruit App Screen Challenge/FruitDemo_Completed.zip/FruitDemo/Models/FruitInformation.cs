﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FruitDemo.Models
{
     public class FruitInformation
     {
          public string Micronutrient { get; set; }
          public int Percentage { get; set; }
     }
}
