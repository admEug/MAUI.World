﻿namespace FruitDemo;

public partial class AppShell : Shell
{
	public AppShell()
	{
		InitializeComponent();
	}
}
